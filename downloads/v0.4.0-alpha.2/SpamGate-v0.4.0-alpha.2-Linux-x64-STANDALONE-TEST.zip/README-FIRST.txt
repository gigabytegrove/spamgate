SpamGate — Linux x64 Standalone Test — v0.4.0-alpha.2

Extract ZIP; open a shell in the extracted directory, then run:

    chmod +x ./spamgate
    ./spamgate -data "$HOME/.local/share/spamgate" -listen 127.0.0.1:38470

Visit http://127.0.0.1:38470 in a browser ON THAT SERVER. For a remote
headless host use an SSH tunnel (-L 38470:127.0.0.1:38470) from your workstation.
The process remains in the foreground; Ctrl+C stops it. The initial admin
claim key is printed to standard error. No installer, service or MTA changes.

This is a DEVELOPMENT TEST BUILD compiled with Go 1.23.2, which is outdated.
Do not use for production mail routing or expose its UI to the Internet.
