SpamGate — Windows x64 Standalone Test — v0.4.0-alpha.2

1. Extract all files to a directory of your choice.
2. Double-click SpamGate.exe (no installer, script, CMD, service registration or admin rights).
3. The local Web UI should open at http://127.0.0.1:38470.
4. For first-run setup the EXE displays a native dialog with your one-time setup key.
5. To stop the application, terminate SpamGate.exe in Task Manager.
6. Persistent data and logs: %LOCALAPPDATA%\SpamGate\.

This is an UNSIGNED DEVELOPMENT TEST BUILD compiled with Go 1.23.2, which is outdated.
Do not use this build for production mail filtering, expose its interface to the Internet,
or bypass Windows Defender/SmartScreen. Native Windows startup and Defender clearance
have not been verified here. No installer or background service is included.
